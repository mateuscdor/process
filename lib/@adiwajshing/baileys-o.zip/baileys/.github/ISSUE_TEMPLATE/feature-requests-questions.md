---
name: Feature Requests/Questions
about: Template for general issues/feature requests/questions
title: ''
labels: ''
assignees: ''

---

**Before adding this issue, make sure you do the following to make sure this is not a duplicate:**
1. Search through the repo's previous issues
2. Read through the readme at least once
3. Search the docs for the feature you're looking for

**Just describe the feature/question**
